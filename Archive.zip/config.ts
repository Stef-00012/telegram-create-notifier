export const config = {
    token: "7784739406:AAGdEMCxQ5Vi3DuBOUbdRH9Svyd03WySaTM"
}