import { chats } from "./schemas/chats"

export default {
	chats
};
